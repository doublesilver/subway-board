
  # Subway Board Chat App

  This is a code bundle for Subway Board Chat App. The original project is available at https://www.figma.com/design/BXWXchou9Z5f197btUr57M/Subway-Board-Chat-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  